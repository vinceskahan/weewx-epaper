English:
This directory holds our pre-compiled sample programs. 
You can use them for evaluation if you have trouble setting up your environment.

中文：
本目录存放的是我们预先编译好的示例程序。如果您在环境搭建时遇到了麻烦，可以使用它们进行评估。